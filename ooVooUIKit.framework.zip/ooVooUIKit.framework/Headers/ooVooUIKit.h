//
//  ooVooUIKit.h
//  ooVooUIKit
//
//  Created by Udi on 11/01/2016.
//  Copyright © 2016 Udi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ooVooUIKit.
FOUNDATION_EXPORT double ooVooUIKitVersionNumber;

//! Project version string for ooVooUIKit.
FOUNDATION_EXPORT const unsigned char ooVooUIKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like

#import <ooVooUIKit/Message.h>


